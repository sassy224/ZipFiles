﻿namespace CustomRenderer
{
	public enum CameraOptions
	{
		Rear,
		Front
	}
}
