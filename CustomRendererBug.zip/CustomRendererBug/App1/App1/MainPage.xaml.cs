﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class MainPage : ContentPage
	{
		public MainPage ()
		{
			InitializeComponent ();
            
        }

        private async void Button_Clicked(object sender, System.EventArgs e)
        {
            await this.Navigation.PushAsync(new Page1());
        }
    }
}
