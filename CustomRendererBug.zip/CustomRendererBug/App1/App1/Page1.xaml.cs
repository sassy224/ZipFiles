﻿using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace App1
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class Page1 : ContentPage
	{
		public Page1()
		{
			InitializeComponent ();
		}
	}
}
