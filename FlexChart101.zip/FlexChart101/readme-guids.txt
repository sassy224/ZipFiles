B9FC6566-5006-48CA-B8A0-6353B656F9C0            Common Guid shared by sample with multiple languages.
7212A07F-C927-4323-A11F-D4E1187CD0A3	        Unique Guid for each sample regardless of language.
