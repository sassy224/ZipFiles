FlexChart101 for Xamarin Forms
------------------------------------------
Shows samples of the Chart control.

Shows the following samples

	- GettingStarted with FlexChart
	
	- BasicChartTypes
	- MixedChartTypes
	- FinancialChart
	- BubbleChart
	- FlexChart DataLabels
	- Annotations
	- MultipleAxes
	- FlexChart LegendAndTitles

	- SelectionModes
	- ToggleSeries
	- DynamicCharts
	- HitTest

	- Histogram Chart

	- Theming
	- StylingSeries
	- ExportImage
	- Zones
	- Custom Plot Elements
	- Customizing Axis Labels
	- Custom Tooltips

	- Line Marker
	
	- Zooming and Scrolling

	- Load Animation
	
	- Update Animation
	
	- GettingStarted with FlexPie
	- Basic Features
	- FlexPie LegendAndTitles
	- Selection
	- FlexPie DataLabels

	- FlexPie Theming
	
	- Pie Load Animation
	- Tree Map
	- Custom Plot Elements Scrolling
