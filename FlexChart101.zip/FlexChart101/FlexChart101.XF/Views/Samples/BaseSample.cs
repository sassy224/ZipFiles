﻿
using Xamarin.Forms;

namespace FlexChart101
{
    public class BaseSample : ContentPage
    {
        public BaseSample()
        {
        }
    }
}
